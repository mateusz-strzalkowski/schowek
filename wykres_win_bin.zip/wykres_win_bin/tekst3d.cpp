#include "tekst3d.h"


void Pisacz3d :: zaczepienieZnakow3d( vec3 Poz, vec3 Rown, vec3 Prost, float Skala)
{
	poz = Poz;
	rown = Rown;
	prost = Prost;
	skala = Skala;
}

void Pisacz3d::RysujZnak(unsigned char c)
{
	// Activate corresponding render state	
	shader->use();
	//glUniform3f(glGetUniformLocation(s.Program, "textColor"), color.x, color.y, color.z);
	shader->setVec3("textColor", textColor);
	shader->setInt("text", 0);

	if (projection && model && view)//czyli je�li wska�niki nie wskazuj� na null
	{
		glUniformMatrix4fv(glGetUniformLocation(shader->ID, "projection"), 1, GL_FALSE, (const GLfloat *)&(*projection)[0][0]);
		glUniformMatrix4fv(glGetUniformLocation(shader->ID, "model"), 1, GL_FALSE, (const GLfloat *)&(*model)[0][0]);
		glUniformMatrix4fv(glGetUniformLocation(shader->ID, "view"), 1, GL_FALSE, (const GLfloat *)&(*view)[0][0]);
	}
	glActiveTexture(GL_TEXTURE0);
	glBindVertexArray(txtVAO);

	Character ch = ttf->Characters[c];

	vec3 pzn = poz; //pozycja znaku
	pzn += (skala * ch.Bearing.x ) * rown;
	pzn += (-skala * (ch.Size.y - ch.Bearing.y) ) * prost;

	vec3 w = (ch.Size.x * skala) *rown;
	vec3 h = (ch.Size.y * skala) *prost;
/*
	GLfloat xpos = lx + ch.Bearing.x * scale;
	GLfloat ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

	GLfloat w = ch.Size.x * scale;
	GLfloat h = ch.Size.y * scale;
*/
	// Update VBO for each character
	vec3 ld = pzn;			//lewy g�rny
	vec3 lg = pzn + h;		//lewy g�rny
	vec3 pd = pzn + w;		//prawy dolny
	vec3 pg = pzn + w + h;  //prawy g�rny
	/*
	GLfloat vertices[6][5] = {
		{ ld.x, ld.y, ld.z,   0.0, 0.0 },
		{ lg.x, lg.y, lg.z,   0.0, 1.0 },
		{ pg.x, pg.y, pg.z,   1.0, 1.0 },

		{ ld.x, ld.y, ld.z,   0.0, 0.0 },
		{ pg.x, pg.y, pg.z,   1.0, 1.0 },
		{ pd.x, pd.y, pd.z,   1.0, 0.0 }
	};
	*/
	/*
	GLfloat vertices[6][5] = {
	{ ld.x, ld.y, ld.z,   1.0, 1.0 },
	{ lg.x, lg.y, lg.z,   1.0, 0.0 },
	{ pg.x, pg.y, pg.z,   0.0, 0.0 },

	{ ld.x, ld.y, ld.z,   1.0, 1.0 },
	{ pg.x, pg.y, pg.z,   0.0, 0.0 },
	{ pd.x, pd.y, pd.z,   0.0, 1.0 }
	};
	*/

	GLfloat vertices[6][5] = {
	{ ld.x, ld.y, ld.z,   0.0, 1.0 },
	{ lg.x, lg.y, lg.z,   0.0, 0.0 },
	{ pg.x, pg.y, pg.z,   1.0, 0.0 },

	{ ld.x, ld.y, ld.z,   0.0, 1.0 },
	{ pg.x, pg.y, pg.z,   1.0, 0.0 },
	{ pd.x, pd.y, pd.z,   1.0, 1.0 }
	};
	

	// Render glyph texture over quad
	glBindTexture(GL_TEXTURE_2D, ch.TextureID);
	// Update content of VBO memory
	glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	// Render quad
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDrawArrays(GL_TRIANGLES, 0, 6);

	// Przesun pozycj� "kursora" na nast�pny znak (wzd�u� wektora r�wnoleg�ego)
	poz += (ch.Advance * skala) * rown;
	glDisable(GL_BLEND);
	
}
/*
void nic() {
	Shader * s = cieniowacz;


	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	// Activate corresponding render state	
	s->use();
	//glUniform3f(glGetUniformLocation(s.Program, "textColor"), color.x, color.y, color.z);
	s->setVec3("textColor", textColor);
	s->setInt("text", 0);
	glActiveTexture(GL_TEXTURE0);
	glBindVertexArray(txtVAO);

	GLfloat x = zaczepienieOkna.x, y = zaczepienieOkna.y;
	GLfloat scale = 1.0f / liczba_linii;
	// Iteracja po liniach
	for (int wrsz = 0; wrsz < linie.size() && y < 1.1; wrsz++)//wiersz
	{
		GLfloat lx = x; //pozycja x dla pojedynczej linii

		GLfloat zazn[4][2] = { 0 };

		s->use();
		glBindVertexArray(txtVAO);

		//iteracja po znakach linii
		string & linia = linie[wrsz];
		int txtrozm = linia.size();
		for (int c = 0; c < txtrozm; c++)
		{
			//metryki znaku
			Character ch = ttf->Characters[linia[c]];

			GLfloat xpos = lx + ch.Bearing.x * scale;
			GLfloat ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

			GLfloat w = ch.Size.x * scale;
			GLfloat h = ch.Size.y * scale;
			// Update VBO for each character
			GLfloat vertices[6][4] = {
				{ xpos,     ypos + h,   0.0, 0.0 },
				{ xpos,     ypos,       0.0, 1.0 },
				{ xpos + w, ypos,       1.0, 1.0 },

				{ xpos,     ypos + h,   0.0, 0.0 },
				{ xpos + w, ypos,       1.0, 1.0 },
				{ xpos + w, ypos + h,   1.0, 0.0 }
			};
			// Render glyph texture over quad
			glBindTexture(GL_TEXTURE_2D, ch.TextureID);
			// Update content of VBO memory
			glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
			glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			// Render quad
			glDrawArrays(GL_TRIANGLES, 0, 6);

			// Przesun zmienn� na nast�pny znak
			lx += (ch.Advance) * scale;
		}
		y -= 1.0 / liczba_linii;

	}

	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);
	return 0;
}
*/