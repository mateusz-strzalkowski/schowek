#pragma once

extern float termin_modyfikacji;
extern float opoznienie_kompilacji;
extern bool nasluch;//czy nas�uchiwa� modyfikacji za�adowanych plik�w
extern bool dynamiczna_rozdzielczosc;//siatki
extern bool czy_temperatura;
extern bool wireframe;

extern bool czy_podzialka;
extern bool paski;

extern bool cienie;