#include "flagi.h"

float termin_modyfikacji = 0.0;
float opoznienie_kompilacji = 0.15;
bool dynamiczna_rozdzielczosc = true;
bool czy_temperatura = false;
bool nasluch = false;
bool wireframe = false;

bool czy_podzialka = true;
bool paski = true;

bool cienie = false;