//Opengl
#include <glad/glad.h>
#include <GLFW/glfw3.h>

//matematyka typu GLSL (wektory itd)
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//czcionki
#include <ft2build.h>
#include FT_FREETYPE_H

//r�no�ci
#include <misc/stb_image.h>
#include <misc/shader_s.h>
#include <misc/camera.h>
#include <misc/czas_modyf_pliku.h>
//#include <misc/render_text.h>
//
#include <iostream>
#include <conio.h>
#include <map>
#include <vector>

#include<stdio.h>
#include<stdlib.h>
#include<ctime>
#include<regex>

#include "flagi.h"



#ifdef WIN32
#define stat _stat
#endif

using namespace glm;
using namespace std;
//rozmiary okna si� zmieniaj�
extern unsigned int szer_okna;
extern unsigned int wys_okna;


class Edytor :public Napis
{
public:
	enum Tryb { zaznaczenie, kursor };

	//G��WNE SK�ADNIKI
	Tryb tryb = kursor;//czy ma byc kursor czy zaznaczenie
	ivec2 pozKurs = ivec2(1, 2); //pozycja kursora
	ivec2 zaczepZazn = ivec2(-1, -1);//zaznaczenie rozci�ga sie zawsze od pozycji kursora do tego miejsca w kt�rym zacz�to zaznacza�

	//a z tego generuje si� te dwa wektory (�eby by�y w dobrej kolejno�ci)
	ivec2 poczZazn = ivec2(-1, -1);
	ivec2 koniecZazn = ivec2(-1, -1);

	//jaka cz�c kodu ma by� wy�wietlana
	enum tryb_widocznosci {calosc=0, funkcja=1, wzor=2};
	tryb_widocznosci TrybWidocznosci = funkcja;
	int liniaPoczatkuWidocznosci = 0;
	int liniaKoncaWidocznosci = 0;

	float poprz_modyfikacja;//tj ostatnie nacisniecie klawisza
	__int64 poprz_czas_modyfikacji_pliku = 0;//na dysku (unixowy czas w sekundach)

	Shader * zaznsh = nullptr;

	GLuint zaznVAO, zaznVBO;

	string typ_shadera;

	struct Blad {
		int nr_linii;
		string tresc;
		vec3 kolor;
	};
	vector<Blad> bledy;

	Napis * pasekgorny=nullptr;
	//RAMKA - OBSZAR TEKSTU W OKNIE	
	//vec2 ramkaLG = vec2(-1,1);//LEWA G�RNA
	//vec2 ramkaPD = vec2(1, -1);//PRAWA DOLNA	
	//string bledy_kompilacji;
	//SKLADNIKI ZAPEWNIONE JUZ PRZEZ KLASE NAPIS
	//vec2 zaczepienieOkna = vec2(-1, 0);//zaczepienie obszaru edytora w oknie
	//vector<string> linie;
	//string zlozoneLinie;
	//string nazwaPliku;
	//
	//Shader * cieniowacz = nullptr;

	//TTF * ttf = nullptr;//czcionka
	//int liczba_linii = 15;

	//GLuint txtVAO, txtVBO;

	Edytor(vec2 zacz, TTF * metryki_czcionek, string typ) :Napis(zacz, metryki_czcionek)
	{
		liczba_linii = 20;
		//obszar pisania
		ramkaGora = 1.0 - (1.0 / liczba_linii)*2;
		ramkaDol = -1.0 + 1.0 / liczba_linii;

		zaczepienieOkna = zacz;
		typ_shadera = typ;
		//nazwa pliku
		time_t tt; struct tm * ti; time(&tt); ti = localtime(&tt);//czas 
		nazwaPliku = string("niezatytulowany z ") + asctime(ti);

		//pasek na g�rze (nazwa pliku)
		pasekgorny = new Napis(glm::vec2(-0.5, 0.95), ttf);
		pasekgorny->liczba_linii = 21; string a = "NULL";
		pasekgorny->ustawString(a, "...");
		pasekgorny->textColor = glm::vec3(0.3, 0.3, 0.3);
		//Shadery
		zaznsh = new Shader("cieniowacze/zaznaczenie.vert", "cieniowacze/zaznaczenie.frag");
		//wczytanie czcionek
		//ttf = new TTF("czcionki/arial.ttf", 48);
		//bufor dla zaznacze� i kursora
		//ustawienia do rysowania czcionek
		glGenVertexArrays(1, &zaznVAO);
		glGenBuffers(1, &zaznVBO);
		glBindVertexArray(zaznVAO);
		glBindBuffer(GL_ARRAY_BUFFER, zaznVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 4 * 2, NULL, GL_DYNAMIC_DRAW);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(GLfloat), 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindVertexArray(0);

		zaznacz_modyfikacje();
		//bledy.push_back({ 0,string("zero"), vec3(0.1, 0.7, 0.1) });
		printf("konstruktor Edytora - bledy: \"%d\"\n", glGetError());
		//int A =glGetError();
	}
	~Edytor()
	{
		delete cieniowacz;
		delete ttf;
		delete zaznsh;
		delete pasekgorny;
		printf("kuniec edytora na %d\n", this);
	}

	string & zwrocString()
	{
		zlozoneLinie.clear();
		for (int w = 0, lim = linie.size(); w < lim; w++)
		{
			zlozoneLinie += linie[w];
		}
		return zlozoneLinie;
	}

	void ustawString(string & in, string nazwa)
	{
		nazwaPliku = nazwa;
		//string s = nazwaPliku.substr(nazwaPliku.begin + nazwaPliku.find_last_of("/", 0), nazwaPliku.end);
		string nzw = nazwa;
		pasekgorny->ustawString(nzw, "nazwaPliku");
		pasekgorny->zaczepienieOkna.x = 0 - nzw.size() / 2 * (1.0 / pasekgorny->liczba_linii / 2);//quasi-wy�rodkowanie;

		linie.clear();
		//cout << in;
		std::istringstream f(in);
		std::string linia;
		//ileLinii = 0;
		while (std::getline(f, linia))
		{
			//std::cout << linia << std::endl;
			linie.push_back(linia + "\n");
		}
		pozKurs = ivec2(0, 0);
		zaznacz_modyfikacje();
	}
	void ustawBledy(char * ble)//komunikaty o bledach
	{
		
		//spr�buj otworzy� plik loga
		ofstream plik;
		bool plikOtwarto = true;
		try { plik.open(nazwaPliku + ".errorlog"); }
		catch (std::runtime_error) { plikOtwarto = false; printf("NIE MOZNA OTWORZYC LOGA DO ZAPISU\n"); }

		//je�eli s� jakie� b��dy
		if (ble != NULL) 
		{ 
			printf("@%s@", ble);
			bledy.clear();
			/*string b(ble, 1024);
			std::istringstream in(b);
			string linijka;
			int line = 0;
			regex wzorzec("0.(\\d{1,}). (.*)\\n");

			while (std::getline(in, linijka))
			{
				cout << "$"<<linijka <<"$"<< endl;
				smatch wynik; // tutaj b�dzie zapisany wynik
				++line;
				if (regex_search(linijka, wynik, wzorzec))
					cout << "Linia " << line << " : " << wynik[0] << '\n';

			}
			*/
			//myfile << this->zwrocString();
			//myfile.close();
			

			//regex wzorzec("0.([0-9]{1,}). .*?[0-9]. (.*) ");
			regex wzorzec("0.([0-9]{1,})..*?[0-9]. (.*) ");
			string linijka;
			istringstream in(ble);
			int l = 0;
			while (std::getline(in, linijka))
			{
				cout <<"$"<< linijka << "$\n";
				smatch wynik;
				++l;
				if (regex_search(linijka, wynik, wzorzec))
				{
					
					cout << "LINIA:" << string(wynik[1]) << "\n";
					cout << "KOMUNIKAT:" << string(wynik[2]) << "\n";
					//cout << "Linia " << l << " : \n" << wynik[0] << "\n" << wynik[1] << '\n';
					//bledy.push_back({ stoi(wynik[1])-1, string(wynik[2]), vec3(1,0,0) });
					bledy.push_back({ stoi(wynik[1]) - 1, linijka, vec3(1,0,0) });
					if (plikOtwarto) { plik << linijka; }
				}
				//je�li zmiany pochdz� z pliku przestaw kursor na ostatni powsta�y b��d.
				if (nasluch) { pozKurs.y = bledy[bledy.size() - 1].nr_linii; if (pozKurs.x >= linie[pozKurs.y].length()) { pozKurs.x = 0; } }
			}
		}
		else { bledy.clear(); printf("ok\n"); if (plikOtwarto) { plik << "ok"; } }
		
		//cout << string(ble) <<"\n";
		//istream in(string(ble));
		if (plikOtwarto) { plik.close(); }

	}

	void zapisz()
	{
		cout << "zapis do" << nazwaPliku << endl;
		ofstream myfile;
		myfile.open(nazwaPliku);
		myfile << this->zwrocString();
		myfile.close();
	}
	void przeladuj_z_pliku()
	{
		__int64 t = czas_modyf_pliku(nazwaPliku.c_str());//sprawd� czas midyfikacji,
		if (t > poprz_czas_modyfikacji_pliku)//je�eli dokonano jej p�niej ni� podczas poprzedniego sprawdzenia, prze�aduj
		{
			poprz_czas_modyfikacji_pliku = t;
			std::ifstream t(nazwaPliku);
			std::stringstream buffer;
			auto dl = t.tellg();
			buffer << t.rdbuf();
			//cout << buffer.str();
			//cout << "EOF\n";
			string s = buffer.str();
			ustawString(s, nazwaPliku);
			printf("na dysku COS");
			zaznacz_modyfikacje();
		}
		else { printf("na dysku nic"); }
	}
//	inline void liniopis(string linia, int txtrozm, TTF * ttf, int lx, int y,int wrsz, float * zazn, float scale, Shader *s, vec3 kolor)
	
//RYSOWANIE TEKSTU NA BUFOR
	//(przerobi� z u�yciem iterator�w?)
	int pisz()
	{

		Shader * s = cieniowacz;
		Shader * zsh = zaznsh;


		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		zsh->use();
		zsh->setVec4("kolorZazn", vec4(0.3, 0.3, 0.5, 1.0));
		// Activate corresponding render state	
		s->use();
		s->setVec3("textColor", textColor);
		s->setInt("text", 0);
		glActiveTexture(GL_TEXTURE0);
		glBindVertexArray(txtVAO);

		GLfloat x = zaczepienieOkna.x, y = zaczepienieOkna.y;
		GLfloat scale = 1.0f / liczba_linii;
		// Iteracja po liniach
		for (int wrsz = 0, blicz=0; wrsz < linie.size(); wrsz++)//wiersz (i jeszcze licznik na tablicy z bledami)
		{
			GLfloat lx = x; //pozycja x dla pojedynczej linii

			GLfloat zazn[4][2] = { 0 };

			s->use();
			s->setVec3("textColor", textColor);
			glBindVertexArray(txtVAO);

			//iteracja po znakach linii
			//liniopis(string linia, TTF * ttf, int lx, int y,float scale, Shader *s, vec3 kolor)

			string linia = linie[wrsz];
			//ewentualna zamiana return na f(x,z,t)= we wzorze funkcji
			if (TrybWidocznosci == funkcja) {size_t n = linia.find("    return", 0);  if (n != string::npos && wrsz==liniaPoczatkuWidocznosci) { linia.replace(n, 10, " f(x,z,t)="); } }
			//TU NAST�PUJE WSTRZYKIWANIE B��D�W, (tzn. linii z opisami b��d�w)
			if ((blicz < bledy.size()) && (wrsz - 1 == bledy[blicz].nr_linii)) { linia = bledy[blicz].tresc; s->setVec3("textColor", bledy[blicz].kolor ); wrsz--; blicz++; }//magia!
			//P�TLA PO ZNAKACH LINII
			int txtrozm = linia.size();
			for (int c = 0; c < txtrozm; c++)
			{
				if (lx > ramkaPrawo) { lx = ramkaLewo; y -= 1.0 / liczba_linii;}
				//metryki znaku
				Character ch = ttf->Characters[linia[c]];
				GLfloat xpos = lx + ch.Bearing.x * scale;
				GLfloat ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

				GLfloat w = ch.Size.x * scale;
				GLfloat h = ch.Size.y * scale;
				// Update VBO for each character
				GLfloat vertices[6][4] = {
					{ xpos,     ypos + h,   0.0, 0.0 },
					{ xpos,     ypos,       0.0, 1.0 },
					{ xpos + w, ypos,       1.0, 1.0 },

					{ xpos,     ypos + h,   0.0, 0.0 },
					{ xpos + w, ypos,       1.0, 1.0 },
					{ xpos + w, ypos + h,   1.0, 0.0 }
				};
				// 
				glBindTexture(GL_TEXTURE_2D, ch.TextureID);
				// Update content of VBO memory
				glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
				glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
				glBindBuffer(GL_ARRAY_BUFFER, 0);
				if ((y<ramkaGora-h) && (y>ramkaDol) &&  (wrsz>=liniaPoczatkuWidocznosci && wrsz<=liniaKoncaWidocznosci )  )
				{
					// Narysuj prostok�t
					glDrawArrays(GL_TRIANGLES, 0, 6);
				}

				//dane do rysowania kursora na ekranie
				if ((tryb == kursor) && (pozKurs == ivec2(c, wrsz)))
				{
					//printf("kursorek(%d, %d)\n", c , wrsz);
					GLfloat d = (ch.Advance) * scale - w;
					zazn[0][0] = xpos - d;			zazn[0][1] = y - 1.0f / liczba_linii / 10;
					zazn[1][0] = xpos - d;			zazn[1][1] = y;
					zazn[2][0] = xpos + w + d;		zazn[2][1] = y - 1.0f / liczba_linii / 10;
					zazn[3][0] = xpos + w + d;		zazn[3][1] = y;

					if (zazn[2][0] > 1.0) { zaczepienieOkna.x -= ((ch.Advance)*scale); }
					if (zazn[0][0] < -1.0) { zaczepienieOkna.x += ((ch.Advance)*scale); }
					if (zazn[1][1] > ramkaGora) { zaczepienieOkna.y -= 1.0f/liczba_linii; }
					if (zazn[0][1] < ramkaDol) { zaczepienieOkna.y += 1.0f / liczba_linii;}
					//if (zazn[2][0] > 1.0) { zaczepienieOkna.x = xpos + w +(ch.Advance)*scale); d - 2.0; }
					//if (zazn[0][0] < -1.0) { zaczepienieOkna.x = xpos - d; }
				}



				// Przesun zmienn� na nast�pny znak
				lx += (ch.Advance) * scale;
			}
			y -= 1.0 / liczba_linii;
			//narysuj zaznaczenie lub kursor dla danej linii
			zsh->use();
			glBindVertexArray(zaznVAO);
			glBindBuffer(GL_ARRAY_BUFFER, zaznVBO);
			glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(zazn), zazn);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		}

		glBindVertexArray(0);
		glBindTexture(GL_TEXTURE_2D, 0);

		pasekgorny->pisz();
		return 0;
	}

	void klawisz_fizyczny(int key, int action)
	{	//SHIFT
		static bool shift = false;
		if (key == GLFW_KEY_LEFT_SHIFT && action == GLFW_PRESS)
			shift = true;
		if (key == GLFW_KEY_LEFT_SHIFT && action == GLFW_RELEASE)
			shift = false;

		//PRZESUWANIE KURSORA
		if (key == GLFW_KEY_LEFT && action != GLFW_RELEASE && pozKurs.x > 0)
			pozKurs.x--;
		if (key == GLFW_KEY_RIGHT && action != GLFW_RELEASE && pozKurs.x < linie[pozKurs.y].size() - 1)
			pozKurs.x++;
		if (key == GLFW_KEY_UP && action != GLFW_RELEASE && pozKurs.y > 0)
			pozKurs.y--;
		if (key == GLFW_KEY_DOWN && action != GLFW_RELEASE && pozKurs.y < linie.size() - 1)
			pozKurs.y++;
		if (pozKurs.x > linie[pozKurs.y].size() - 1) { pozKurs.x = linie[pozKurs.y].size() - 1; }
		// warunek "&& action != GLFW_RELEASE" - znaczy, �e jesli przytrzymamy strzalke, to kursor bedzie sie stale przesuwac, natomiast  action==GLFW_PRESS - tylko raz przy wcisnieciu

		//przesuwanie widoku w g�r�/d�
		if (key == GLFW_KEY_PAGE_UP && action == GLFW_PRESS)
			zaczepienieOkna.y += 1.0f / liczba_linii;
		if (key == GLFW_KEY_PAGE_DOWN && action == GLFW_PRESS)
			zaczepienieOkna.y -= 1.0f / liczba_linii;

		//BACKSPACE - kasowanie
		if (key == GLFW_KEY_BACKSPACE && action != GLFW_RELEASE && pozKurs.x >= 0)
		{
			if (pozKurs.x == 0 && pozKurs.y > 0)
			{
				pozKurs.x = linie[pozKurs.y - 1].size() - 1;
				linie[pozKurs.y - 1].pop_back();
				linie[pozKurs.y - 1] += linie[pozKurs.y];
				linie.erase(linie.begin() + pozKurs.y--);

			}
			else if (pozKurs.x > 0) { linie[pozKurs.y].erase(--pozKurs.x, 1); }
			zaznacz_modyfikacje();
		}
		//NOWA LINIA
		if (key == GLFW_KEY_ENTER && action == GLFW_PRESS)
		{
			//linie.insert(linie.begin() + pozKurs.y + 1, linie[pozKurs.y].substr(0, pozKurs.x));
			linie.insert(linie.begin() + pozKurs.y + 1, linie[pozKurs.y].substr(pozKurs.x, (linie[pozKurs.y].size() - pozKurs.x)));
			linie[pozKurs.y] = linie[pozKurs.y].substr(0, pozKurs.x) + "\n";
			pozKurs.y++;
			//linie.insert(linie.begin() + ++pozKurs.y, "\n"); pozKurs.x = 0;
			zaznacz_modyfikacje();
		}
		//TAB - 4 spacje
		if (key == GLFW_KEY_TAB && action == GLFW_PRESS)
		{
			linie[pozKurs.y].insert(pozKurs.x, "    "); pozKurs.x += 4;
			zaznacz_modyfikacje();
		}

		//ZAPISZ
		if (key == GLFW_KEY_F2 && action == GLFW_PRESS)
			zapisz();

		if (key == GLFW_KEY_F7 && action == GLFW_PRESS)
		{
			printf("F7:%d @ %d\n", TrybWidocznosci, this);
			switch (TrybWidocznosci)
			{
				case calosc: TrybWidocznosci = funkcja; break;
				case funkcja: TrybWidocznosci = calosc; break;
			}
			ustawWidocznosci();
		}

		if (shift)
		{
			if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS)
				printf("zaznaczenie");
		}
	}
	void klawisz_logiczny(unsigned int in)
	{
		//printf("%c\t%d\n", in, in);
		string * a = &linie[pozKurs.y];
		if (pozKurs.x == a->size()) { a->push_back((char)in); ++pozKurs.x; }
		else { a->insert(a->begin() + ++pozKurs.x - 1, (char)in); }
		zaznacz_modyfikacje();

	}
	inline void ustawWidocznosci()
	{
		/*int i = 0; size_t s;  while (((s = linie[i].find("float f(", 0)) != string::npos) && i < linie.size()) { i++; };
		if (s != string::npos) { 
			liniaPoczatkuWidocznosci = i; 

			while (s != string::npos && i < linie.size())
			{
				s=linie[i].find("}")
			}
		}
		else { liniaPoczatkuWidocznosci = 0; liniaKoncaWidocznosci = linie.size() - 1; }
		*/
		if (TrybWidocznosci == calosc) { liniaPoczatkuWidocznosci = 0; liniaKoncaWidocznosci = linie.size() - 1; }

		int poczfun = 0; size_t p = string::npos;  while (poczfun < linie.size()) { p = linie[poczfun].find("float f(", 0); if (p != string::npos) { break; } poczfun++;}
		if (TrybWidocznosci == funkcja)
		{
			int i = poczfun; size_t s=string::npos;  while (i < linie.size() && ( (s = linie[i].find("  return", 0)) == string::npos)) { i++;  };
			if (s != string::npos) { liniaPoczatkuWidocznosci = (liniaKoncaWidocznosci = i); pozKurs.y = i; zaczepienieOkna.y = -1.0 + (i+2) * 1.0 / liczba_linii; }
			else { liniaPoczatkuWidocznosci = 0; liniaKoncaWidocznosci = linie.size() - 1;  }
		}
		//printf("***********L:%d %d\n", liniaPoczatkuWidocznosci, liniaKoncaWidocznosci);
	}

	void zaznacz_modyfikacje()
		//ustawienie zmiennej globalnej termin_modyfikacji powoduje po pewnym czasie kompilacj�
	{
		ustawWidocznosci();
		poprz_modyfikacja = glfwGetTime();
		termin_modyfikacji = poprz_modyfikacja;//zmienna globalna
		printf("%f\n", termin_modyfikacji);
	}


private:

};
