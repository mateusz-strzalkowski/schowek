#include <glad/glad.h>
#include <glm/glm.hpp>
#include <GLFW/glfw3.h>
#include <iostream>
#include <stdio.h>
#include<string>
#include "parametry_tablic_wierzcholkow.h"

using namespace std;
typedef struct krotka {
	string tekst;
	int dlugosc = 0;
};

void krotkopis(krotka * k)
{
	cout << "\n" << k->tekst << " dl:" << k->dlugosc;
}

krotka wzorce[] = { {"vec3", 3},{"float", 1},{"vec2", 2} };

void parametry(const char * Cwejscie, unsigned int VAO)
{
	string in(Cwejscie);
	for (int i = 0; i < in.length(); i++)	{ if (in[i] == ' ') { in.erase(i, 1); } }//skasuj spacje
	cout << "\nwejscie:" << in;
	//cout << "\nwzorce:";
	//for (int i = 0; i < 2; i++) { krotkopis(&wzorce[i]); }

	int lewy = 0; int prawy; bool stop = false;
	//GLint *maxp=NULL; glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, maxp);
	krotka param[16]; int nparam = 0;
	int krok = 0;//stride - dlugosc calego wiersza

	for (nparam = 0; nparam < 16 && lewy < in.length(); nparam++)
	{
		prawy = in.find(",", lewy);
		if (prawy > in.length()) { prawy = in.length(); stop = true; }
		//cout << "\n" << in.substr(lewy, prawy - lewy);
		param[nparam].tekst = in.substr(lewy, prawy - lewy);
		lewy = prawy; lewy++;

		for (int j = 0; ; j++)
		{
			if (param[nparam].tekst == wzorce[j].tekst) { param[nparam].dlugosc = wzorce[j].dlugosc;  krok += wzorce[j].dlugosc;  break; }
			if (j >= sizeof(wzorce) / sizeof(krotka)) { param[nparam].dlugosc = 1; break; }//warunek konca
		}

	}

	for (int i = 0; i < nparam; i++) { krotkopis(&param[i]); }cout << "\n krok:" << krok << endl;

	//wo�anie funkcji
	glBindVertexArray(VAO);
	for (int i = 0, offset = 0; i < nparam; i++)
	{
		glVertexAttribPointer(i, param[i].dlugosc, GL_FLOAT, GL_FALSE, krok * sizeof(float), (void*)(offset * sizeof(float)));
		glEnableVertexAttribArray(i);
		offset += param[i].dlugosc;
	}

}
