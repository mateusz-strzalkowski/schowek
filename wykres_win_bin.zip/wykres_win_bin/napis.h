#pragma once

//Opengl
#include <glad/glad.h>
#include <GLFW/glfw3.h>

//matematyka typu GLSL (wektory itd)
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <misc/shader_s.h>
//#include<misc/ttf.h>			//generacja metryk czcionek true type do p�niejszego u�ytku

#include<vector>
#include<iostream>
#include<string>

#include "flagi.h"

using namespace glm;
using namespace std;

class Napis
{
public:
	vec2 zaczepienieOkna = vec2(-1, 0);//zaczepienie obszaru edytora w oknie
	vector<string> linie;
	string zlozoneLinie;
	string nazwaPliku;
	//
	Shader * cieniowacz = nullptr;
	TTF * ttf = nullptr;//czcionka
	vec3 textColor = vec3(0, 1, 1);
	int liczba_linii = 15;

	//RAMKA - OBSZAR TEKSTU W OKNIE	
	float ramkaGora = 1.0;
	float ramkaDol = -1.0;
	float ramkaPrawo = 1.0;
	float ramkaLewo = -1.0;

	GLuint txtVAO, txtVBO;

	Napis(vec2 zacz, TTF * metryki_czcionek)
	{
		zaczepienieOkna = zacz;
		//Shadery
		cieniowacz = new Shader("cieniowacze/edytor.vert", "cieniowacze/edytor.frag");
		//wczytanie czcionek
		ttf = metryki_czcionek;
		//ustawienia do rysowania czcionek
		glGenVertexArrays(1, &txtVAO);
		glGenBuffers(1, &txtVBO);
		glBindVertexArray(txtVAO);
		glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindVertexArray(0);
		//bufor dla zaznacze� i kursora
		//ustawienia do rysowania czcionek
		printf("ustawienia ttf %d\n", glGetError());

		//rozdziel tekst na linie
		std::istringstream f("line1\nline2\nline3");
		std::string linia;
		//ileLinii = 0;
		while (std::getline(f, linia))
		{
			std::cout << linia << std::endl;
			linie.push_back(linia + "\n");
		}

		printf("konstruktor napis\n");
	}
	~Napis()
	{
		delete cieniowacz;
		printf("destruktor napisu na %d\n", this);
	}

	string & zwrocString()
	{
		zlozoneLinie.clear();
		for (int w = 0, lim = linie.size(); w < lim; w++)
		{
			zlozoneLinie += linie[w];
		}
		return zlozoneLinie;
	}

	void ustawString(string & in, string nazwa)
	{
		nazwaPliku = nazwa;

		linie.clear();
		//cout << in;
		std::istringstream f(in);
		std::string linia;
		//ileLinii = 0;
		while (std::getline(f, linia))
		{
			//std::cout << linia << std::endl;
			linie.push_back(linia + "\n");
		}
		//pozKurs = ivec2(0, 0);
	}

	int pisz()
	{

		Shader * s = cieniowacz;


		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		// Activate corresponding render state	
		s->use();
		//glUniform3f(glGetUniformLocation(s.Program, "textColor"), color.x, color.y, color.z);
		s->setVec3("textColor", textColor);
		s->setInt("text", 0);
		glActiveTexture(GL_TEXTURE0);
		glBindVertexArray(txtVAO);

		GLfloat x = zaczepienieOkna.x, y = zaczepienieOkna.y;
		GLfloat scale = 1.0f / liczba_linii;
		// Iteracja po liniach
		for (int wrsz = 0; wrsz < linie.size() && y < 1.1; wrsz++)//wiersz
		{
			GLfloat lx = x; //pozycja x dla pojedynczej linii

			GLfloat zazn[4][2] = { 0 };

			s->use();
			glBindVertexArray(txtVAO);

			//iteracja po znakach linii
			string & linia = linie[wrsz];
			int txtrozm = linia.size();
			for (int c = 0; c < txtrozm; c++)
			{
				//metryki znaku
				Character ch = ttf->Characters[linia[c]];

				GLfloat xpos = lx + ch.Bearing.x * scale;
				GLfloat ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

				GLfloat w = ch.Size.x * scale;
				GLfloat h = ch.Size.y * scale;
				// Update VBO for each character
				GLfloat vertices[6][4] = {
					{ xpos,     ypos + h,   0.0, 0.0 },
					{ xpos,     ypos,       0.0, 1.0 },
					{ xpos + w, ypos,       1.0, 1.0 },

					{ xpos,     ypos + h,   0.0, 0.0 },
					{ xpos + w, ypos,       1.0, 1.0 },
					{ xpos + w, ypos + h,   1.0, 0.0 }
				};
				// Render glyph texture over quad
				glBindTexture(GL_TEXTURE_2D, ch.TextureID);
				// Update content of VBO memory
				glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
				glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
				glBindBuffer(GL_ARRAY_BUFFER, 0);
				// Render quad
				glDrawArrays(GL_TRIANGLES, 0, 6);

				// Przesun zmienn� na nast�pny znak
				lx += (ch.Advance) * scale;
			}
			y -= 1.0 / liczba_linii;

		}

		glBindVertexArray(0);
		glBindTexture(GL_TEXTURE_2D, 0);
		return 0;
	}


	int pisz2()
	{

		Shader * s = cieniowacz;

		vec3 color(0, 1, 1);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		// Activate corresponding render state
		s->use();
		//glUniform3f(glGetUniformLocation(s.Program, "textColor"), color.x, color.y, color.z);
		s->setVec3("textColor", color);
		s->setInt("text", 0);
		glActiveTexture(GL_TEXTURE0);
		glBindVertexArray(txtVAO);

		GLfloat x = zaczepienieOkna.x, y = zaczepienieOkna.y;
		GLfloat scale = 1.0f / liczba_linii;
		// Iteracja po liniach
		for (int wrsz = 0; wrsz < linie.size() && y < 1.1; wrsz++)//wiersz
		{
			GLfloat lx = x; //pozycja x dla pojedynczej linii

			GLfloat zazn[4][2] = { 0 };

			s->use();
			glBindVertexArray(txtVAO);

			piszLinijke(linie[wrsz], lx, y, scale);

			y -= 1.0 / liczba_linii;

		}

		glBindVertexArray(0);
		glBindTexture(GL_TEXTURE_2D, 0);
		return 0;
	}

	void inline piszLinijke(string & linia, GLfloat lx, GLfloat y, GLfloat scale)
	{
		int txtrozm = linia.size();
		for (int c = 0; c < txtrozm; c++)
		{
			//metryki znaku
			Character ch = ttf->Characters[linia[c]];

			GLfloat xpos = lx + ch.Bearing.x * scale;
			GLfloat ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

			GLfloat w = ch.Size.x * scale;
			GLfloat h = ch.Size.y * scale;
			// Update VBO for each character
			GLfloat vertices[6][4] = {
				{ xpos,     ypos + h,   0.0, 0.0 },
				{ xpos,     ypos,       0.0, 1.0 },
				{ xpos + w, ypos,       1.0, 1.0 },

				{ xpos,     ypos + h,   0.0, 0.0 },
				{ xpos + w, ypos,       1.0, 1.0 },
				{ xpos + w, ypos + h,   1.0, 0.0 }
			};
			// Render glyph texture over quad
			glBindTexture(GL_TEXTURE_2D, ch.TextureID);
			// Update content of VBO memory
			glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
			glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			// Render quad
			glDrawArrays(GL_TRIANGLES, 0, 6);

			// Przesun zmienn� na nast�pny znak
			lx += (ch.Advance) * scale;
		}
	}
private:

};


