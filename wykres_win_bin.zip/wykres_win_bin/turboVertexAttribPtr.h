#pragma once
int parametry(const char *, unsigned int);
