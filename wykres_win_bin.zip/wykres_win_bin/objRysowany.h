
//Opengl
#include <glad/glad.h>
#include <GLFW/glfw3.h>

//matematyka typu GLSL (wektory itd)
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <misc/shader_s.h>
//#include<misc/ttf.h>			//generacja metryk czcionek true type do p�niejszego u�ytku

#include<vector>
#include<iostream>
#include<string>
#include "turboVertexAttribPtr.h"

#pragma once
class ObjRysowany
{
public:
	//SK�ADNIKI G��WNE
	float* vertices=nullptr;
	int nvertices = 0;
	unsigned int VBO, VAO;
	unsigned int typGeometrii = 0;

	ObjRysowany( float * vert, int nvert, const char * atr, unsigned int typgeometr)
	{
		printf("========OBJRysowany=======\nnvert = %d", nvert);
		vertices = vert;
		nvertices = nvert;
		typGeometrii = typgeometr;
		//vertices = v;
		// first, configure the cube's VAO (and VBO)
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);

		glBindVertexArray(VAO);
		//magiczna funkcja parametry zast�puje potworne glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
		// np. tym: parametry("vec3, vec2");
		//zwraca dlugosc pojedynczego kawa�ka argument�w
		int dlugoscKawalka = parametry(atr, VAO);

		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, nvertices*dlugoscKawalka *sizeof(float), vertices, GL_STATIC_DRAW);
		printf("glBufferData(GL_ARRAY_BUFFER, %d, vertices, GL_STATIC_DRAW);", nvertices*dlugoscKawalka);
		glBindVertexArray(VAO);
		parametry(atr, VAO);
		/*
		// position attribute
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);
		// normal attribute
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(1);
		*/
	}
	~ObjRysowany()
	{

	}
	void rysuj()
	{
		glBindVertexArray(VAO);
		glDrawArrays(typGeometrii, 0, nvertices);
	}
};