//matematyka typu GLSL (wektory itd)
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "tekst3d.h"

#include "objRysowany.h"
#include "flagi.h"

using namespace glm;

#define BUFSIZE 2048

#pragma once
class Podzialka: public ObjRysowany
{
public:
	//SK�ADNIKI G��WNE
	//float* vertices = nullptr;
	//int nvertices = 0;
	//unsigned int VBO, VAO;
	//unsigned int typGeometrii = 0;
	//:Napis(zacz, metryki_czcionek)
	Shader * shader_osi = nullptr;
	Pisacz3d * pisacz3d = nullptr;

	float poprzednia_rozpietosc=0.0;

	int npodpisow = 0;

	Podzialka() :ObjRysowany(new float[BUFSIZE], 0, "vec3", GL_LINES)
	{
		pisacz3d = new Pisacz3d("cieniowacze/tekst3d.vert", "cieniowacze/tekst3d.frag", "cziconki/arial.ttf", 50);
		generujPodzialke(1.0, vec3(0,0,0));
	}
	~Podzialka()
	{
		delete vertices;
	}
	int generujPodzialke(float rozpietosc, vec3 przesuniecie)
	{
	//KROK - G�STO�� PODZIA�KI
		float krok = pow(10, (int)(log10(rozpietosc)));
		//float w = fun(krok, 1); float m = fun(krok, -1);
		float k = 0; int i = 0;
		k = krok;
		if (rozpietosc / krok < 2) { while (rozpietosc / k < 2) { k = fun(krok, --i); } }
		if (rozpietosc / krok > 11) { while (rozpietosc / k < 15) { k = fun(krok, ++i); } }
		krok = k;


			float * wsk = vertices;
			float poz = 0.0;

			npodpisow = 0;


			generujOs(wsk, rozpietosc, vec3(1, 0, 0), vec3(0, 1, 0), przesuniecie.x, krok);
			if ((wsk - vertices) * 3 > BUFSIZE) { return -1; }
			generujOs(wsk, rozpietosc, vec3(0, 0, 1), vec3(0, 1, 0), przesuniecie.z, krok);
			generujOs(wsk, rozpietosc, vec3(0, 1, 0), vec3(1, 0, 0), przesuniecie.y, krok);

			nvertices = (wsk - vertices) / 3;
			glBindBuffer(GL_ARRAY_BUFFER, VBO);
			glBufferData(GL_ARRAY_BUFFER, nvertices * sizeof(vec3), vertices, GL_DYNAMIC_DRAW);
			//printf("glBufferData(GL_ARRAY_BUFFER, %d, vertices, GL_STATIC_DRAW);", nvertices * sizeof(vec3));
	}
	inline float fun(float x, int n)
	{
		float s = 1;
		for (int i = 0; i < abs(n);i++)
		{
			if (i % 2 == 0) { s *= 2; }
			if (i % 2 == 1) { s *= 5; }
		}
		return (n > 0) ? (x*s) : (x / s);
	}
	/*
	inline void generujOs(float * & wsk, float rozpietosc, vec3 rown, vec3 prost, vec3 przesuniecie, float krok)
	{
		char str[16];
		vec3 poczatek;
		poczatek.x = (c;
		poczatek.y = ((int)(przesuniecie.y / krok))*krok;
		poczatek.z = ((int)(przesuniecie.z / krok))*krok;

		vec3 pozwykr, pozsceny=vec3(0,0,0);//pozycja na wykreie i po przeskallowaniu na scenie
		vec3 pk;//pozycja drugiego konca linii
		for (pozwykr = poczatek; length(pozsceny)<1 ; pozwykr += (krok*rown))
		{
			pozsceny = ((pozwykr - przesuniecie) / rozpietosc);
			pk = pozsceny +(0.03f * prost);
			wrzucvec3(wsk, pozsceny); wrzucvec3(wsk, pk);

			float liczbaNapodzialce = length(pozwykr);

			pisacz3d->zaczepienieZnakow3d(pk, (rown==vec3(0,1,0)) ? (vec3(1,0,0)):(rown) , vec3(0,1,0), 0.05);
			sprintf(str, "%.2f", liczbaNapodzialce);
			for (int i = 0; str[i] != '\0'; i++) { pisacz3d->RysujZnak(str[i]); }
			printf("\n%f", liczbaNapodzialce);
		}
	}
	*/

	inline void generujOs(float * & wsk, float rozpietosc, vec3 rown, vec3 prost, float przesuniecie, float krok)
	{
		float poczatek = ((int)(przesuniecie / krok))*krok;

		float poz;
		vec3 pozsceny;
		char str[16];
		/*
		for (pozwykr = poczatek; length(pozsceny) < 1; pozwykr += krok)
		{
			vec3 p1, p2;
			//z jednej strony 0
			p1 = ((pozwykr+przesuniecie) / rozpietosc) * rown;
			p2 = p1 + (0.03f * prost);
			wrzucvec3(wsk, p1); wrzucvec3(wsk, p2);

			pisacz3d->zaczepienieZnakow3d(p2, rown, prost, 0.05);
			sprintf(str, "%.2f", pozwykr);
			for (int i = 0; str[i] != '\0'; i++) { pisacz3d->RysujZnak(str[i]); }
			pozsceny = p1;
		}
		*/

		for (poz = ((int)(przesuniecie / krok))*krok; poz < (rozpietosc+przesuniecie); poz += krok)
		{
			//printf("poz:%f", poz);
			vec3 p1, p2;
			//z jednej strony 0
			p1 = ((poz-przesuniecie) / rozpietosc) * rown;
			p2 = p1 + (0.03f * prost);
			wrzucvec3(wsk, p1); wrzucvec3(wsk, p2);

			vec3 r; float pz;
			if (rown != vec3(0, 1, 0)) { pz = poz; r = rown; }
			else { pz = poz; r = vec3(1, 0, 0); }
			pisacz3d->zaczepienieZnakow3d(p2, r, vec3(0,1,0), 0.04);
			sprintf(str, "%g", pz);
			for (int i = 0; str[i] != '\0';i++) { pisacz3d->RysujZnak(str[i]); }

		}
		
		for (poz = ((int)(przesuniecie / krok))*krok; poz > -(rozpietosc - przesuniecie); poz -= krok)
		{
			//printf("poz:%f", poz);
			vec3 p1, p2;
			//z jednej strony 0
			p1 = ((poz - przesuniecie) / rozpietosc) * rown;
			p2 = p1 + (0.03f * prost);
			wrzucvec3(wsk, p1); wrzucvec3(wsk, p2);

			vec3 r; float pz;
			if (rown != vec3(0, 1, 0)) { pz = poz; r = rown; }
			else { pz = poz; r = vec3(1, 0, 0); }
			pisacz3d->zaczepienieZnakow3d(p2, r, vec3(0, 1, 0), 0.04);
			sprintf(str, "%g", pz);
			for (int i = 0; str[i] != '\0'; i++) { pisacz3d->RysujZnak(str[i]); }

		}
		
		
	}

	inline void wrzucvec3(float * & wsk, vec3 v)//wrzu� wektor do tablicy
	{
		*wsk = v.x; wsk++;
		*wsk = v.y; wsk++;
		*wsk = v.z; wsk++;

	}


	void rysuj(float rozpietosc, vec3 przesuniecie)
	{
		generujPodzialke(rozpietosc, przesuniecie);
		if (shader_osi != nullptr) { shader_osi->use(); }
		glBindVertexArray(VAO);
		glDrawArrays(typGeometrii, 0, nvertices);
		
		/*pisacz3d->zaczepienieZnakow3d(vec3(0, 0, 0), vec3(1, 1, 0), vec3(-1, 1, 0), 1.0);
		const char * txt = "And behold! For the great power shall be bestowed upon him to wreak havoc on earth!";
		for (int i = 0; txt[i] != '\0'; i++) { pisacz3d->RysujZnak(txt[i]); }
		pisacz3d->zaczepienieZnakow3d(vec3(0, 0, 0), vec3(1, 0, 0), vec3(0, 1, 0), 1.0);
		const char * txt2 = "WRITHED WRAITH  WROKE WRATH";
		for (int i = 0; txt2[i] != '\0'; i++) { pisacz3d->RysujZnak(txt2[i]); }
		*/
		//pisacz3d->ZnakNaBufor('a');
		//pisacz3d->rysujBufor();
	}

	/*ObjRysowany(float * vert, int nvert, const char * atr, unsigned int typgeometr)
	{
		printf("========OBJRysowany=======\nnvert = %d", nvert);
		vertices = vert;
		nvertices = nvert;
		typGeometrii = typgeometr;
		//vertices = v;
		// first, configure the cube's VAO (and VBO)
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);

		glBindVertexArray(VAO);
		//magiczna funkcja parametry zast�puje potworne glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
		// np. tym: parametry("vec3, vec2");
		//zwraca dlugosc pojedynczego kawa�ka argument�w
		int dlugoscKawalka = parametry(atr, VAO);

		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, nvertices*dlugoscKawalka * sizeof(float), vertices, GL_STATIC_DRAW);
		printf("glBufferData(GL_ARRAY_BUFFER, %d, vertices, GL_STATIC_DRAW);", nvertices*dlugoscKawalka);
		glBindVertexArray(VAO);
		parametry(atr, VAO);
		
		// position attribute
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);
		// normal attribute
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(1);
		
	}
*/
};