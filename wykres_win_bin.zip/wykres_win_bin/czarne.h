#ifndef __czarne__
#define __czarne__

float * czarne(float);

#endif