//#include<misc/ttf.h>
#pragma once
//#include<misc/edytor.h>
#include "napis.h"
#include "edytor.h"
class Generator
{
public:

	GLFWwindow* okno;
	unsigned int ramkobufor; //framebuffer
	unsigned int textureColorbuffer;
	unsigned int rbo;//render buffer object
	int szer_ramkobufora, wys_ramkobufora;

	//unsigned int idDynamicznegoShadera;
	DynamicShader * DynamicznyCieniowacz;

	TTF * metryki_czcionek = nullptr;

	Edytor * AktywnyEdytor = nullptr;

	Edytor * VertexEdytor = nullptr;
	Edytor * FragmentEdytor = nullptr;
	Edytor * napis = nullptr;

	Edytor * Edytory[32];
	int ile_edytorow = 0;
	Napis * pasek;

	
	//bool nasluch = false;

	Generator(GLFWwindow * window, DynamicShader * dsh)
	{
		okno = window;
		DynamicznyCieniowacz = dsh;
		metryki_czcionek = new TTF("czcionki/arial.ttf", 48);

		inicjuj_edytory();

		//Napis pasek(glm::vec2(-1.0, -0.9), metryki_czcionek);
		pasek = new Napis(glm::vec2(-1.0, -0.97), metryki_czcionek);
		pasek->liczba_linii = 23;
		pasek->textColor = vec3(0.9, 0.9, 0.7);
		//string tresc_paska("F1 Pomoc F2 Zapisz F3 Przelacz F4 Menu F5 Kompiluj F6 Nasluchuj F7 Rozwiniety F8   F9 Opcje\ndupa\ntereperempumpum");
		string s = tresc_paska();
		pasek->ustawString(s, "pasek_dolny");
		utworz_ramkobufor();
		obraz();
	}
	void inicjuj_edytory()
	{
		//konstrukcja edytorow
		VertexEdytor = new Edytor(glm::vec2(-1, 0), metryki_czcionek, string("VERTEX"));
		FragmentEdytor = new Edytor(glm::vec2(-1, 0.9), metryki_czcionek, string("FRAGMENT"));
		string poczatkowyVertexShader = "wykresy/1.vert"; string poczatkowyFragmentShader = "wykresy/1.frag";
		//wczytaj domyslne sciezki plikow z pliki.ini
		std::ifstream t("pliki.ini");
		t >> poczatkowyVertexShader; t >> poczatkowyFragmentShader; t.close();
		//ustaw tre�� edytorow
		string v = wczytajPlik(poczatkowyVertexShader.c_str());  VertexEdytor->ustawString(v, poczatkowyVertexShader);
		string f = wczytajPlik(poczatkowyFragmentShader.c_str());  FragmentEdytor->ustawString(f, poczatkowyFragmentShader);
		//ustaw kt�ry ma byc aktywny
		AktywnyEdytor = VertexEdytor;
		//tablica edytor�w
		Edytory[0] = VertexEdytor;
		Edytory[1] = FragmentEdytor;
		ile_edytorow = 2;
	}
	 string tresc_paska()
	{
		 string s("");
		 s += "F1 Pomoc F2 Zapisz";
		 s += " F3"; s += AktywnyEdytor->typ_shadera;
		 s += " F4 Menu F5 Kompiluj F6 ";
		 if (!nasluch) { s += "Nasluchuj"; } else { s += "Zatrzymaj"; }

		 s += " F7 ";  if (AktywnyEdytor->TrybWidocznosci == 0) { s += "Rozwiniety"; }
		 else if (AktywnyEdytor->TrybWidocznosci == 1) { s += "Funkcja"; }
		 else { s += "WTF?!"; }

		 s += " F9 Opcje";
		 return s;
		// F3 Przelacz F4 Menu F5 Kompiluj F6 Nasluchuj F7 Rozwiniety F8   F9 Opcje\ndupa\ntereperempumpum";
	}

	~Generator()
	{
		for (int i = 0; i < ile_edytorow; i++)
		{
			delete Edytory[i];
		}
		//delete VertexEdytor;
		//delete FragmentEdytor;
		delete pasek;
		delete metryki_czcionek;
	}

	void utworz_ramkobufor()
	{
		
		glfwGetWindowSize(okno,  &szer_ramkobufora, &wys_ramkobufora);//wydrzyj rozmiar okna

		glGenFramebuffers(1, &ramkobufor);
		glBindFramebuffer(GL_FRAMEBUFFER, ramkobufor);
		// create a color attachment texture
		glGenTextures(1, &textureColorbuffer);
		glBindTexture(GL_TEXTURE_2D, textureColorbuffer);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, szer_ramkobufora, wys_ramkobufora, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, textureColorbuffer, 0);
		// create a renderbuffer object for depth and stencil attachment (we won't be sampling these)
		
		glGenRenderbuffers(1, &rbo);
		glBindRenderbuffer(GL_RENDERBUFFER, rbo);
		glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, szer_ramkobufora, wys_ramkobufora ); // use a single renderbuffer object for both a depth AND stencil buffer.
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, rbo); // now actually attach it
		// now that we actually created the framebuffer and added all attachments we want to check if it is actually complete now
		if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
			cout << "ERROR::FRAMEBUFFER:: Framebuffer is not complete!" << endl;
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
	}
	void kompiluj()
	{
		static char * bledy;
		printf("\nKOMPILACJA\n");
		for (int i = 0; i < ile_edytorow; i++)//Dla ka�dego edytora
		{
			if (Edytory[i]->poprz_modyfikacja != 0.0)//je�eli zmiany nie zosta�y skompilowane
			{
				//spr�buj zamieni� cz�� programu shader�w, ustaw czas modyfikacji na 0 (tzn wprowadzona), prze�lij do edytora ewentualne b��dy kompilacji.
				bledy = DynamicznyCieniowacz->zamien((Edytory[i]->zwrocString()).c_str(), Edytory[i]->typ_shadera);
				Edytory[i]->poprz_modyfikacja = 0.0;//tzn kompilacja zostala dokonana
				Edytory[i]->ustawBledy(bledy);
			}
		}
		if (1)
		{
			string f = VertexEdytor->zwrocString();
			size_t poczf = f.find("float f(", 0);//pocz�tek funkcji
			size_t pierwszynawias = f.find("{", poczf);
			int zagniezdzenie = 1; char c; unsigned int i = pierwszynawias+1  , dlug = f.length(); 
			while (i < dlug && zagniezdzenie>0) 
			{
				if (f[i] == '/' && f[i + 1] == '/')//komentarze (�eby nie liczyc zakomentowanych nawias�w)
				{
					while (f[i] != '\n') { i++; }
				}
				c = f[i];
				if (c == '{') { zagniezdzenie++; }
				if (c == '}') { zagniezdzenie--; }
				i++;
			}
			if (i < dlug)//czyli si� znalaz� koniec
			{
				f = f.substr(pierwszynawias, i-pierwszynawias);
				//cout << "---f(x,y,t)---\n";
				//cout << f;
				//cout << "---/f---\n";
			}
		}

		obraz();
	}
	void obraz()
	{
		glViewport(0, 0, szer_ramkobufora, wys_ramkobufora);
		glBindFramebuffer(GL_FRAMEBUFFER, ramkobufor);//prze��cz si� na drugi bufor
		glEnable(GL_DEPTH_TEST);
		glClearColor(0.00f, 0.00f, 0.00f, 0.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//wyczy�� przypi�ty bufor
		//napisz tektsy
		AktywnyEdytor->pisz();
		pasek->pisz();
		//glfwSwapBuffers(okno);
		glBindFramebuffer(GL_FRAMEBUFFER, 0);//prze��cz si� z powrotem na bufor ekranu

		glViewport(0, 0, szer_okna, wys_okna);//posprz�taj po sobie i ustaw tak jak by�o (na rozmiar bufora 0 - okna)
	}

	void klawisz_fizyczny(int key, int action)
	{
		static int nr_aktywnego = 0;
		//printf("generator:fiz\n");
		if (key == GLFW_KEY_F3 && action == GLFW_PRESS)//PRZE��CZANIE EDYTOR�W
		{
			printf("F3\n");
			nr_aktywnego++;
			if (nr_aktywnego >= ile_edytorow) { nr_aktywnego = 0; }
			AktywnyEdytor = Edytory[nr_aktywnego];
		}
		if (key == GLFW_KEY_F5 && action == GLFW_PRESS)
		{
			//std::cout << (AktywnyEdytor->zwrocString());
			string & s = AktywnyEdytor->zwrocString();
			std::cout << s;
		}
		if (key == GLFW_KEY_F6 && action == GLFW_PRESS)//W��CZENIE NAS�UCHIWANIA
			//(wyzwalacz czasowy znajduje si� w g��wnej p�tli programu)
		{
			printf("F6 nasluchuje %s I %s\n", VertexEdytor->nazwaPliku.c_str(), FragmentEdytor->nazwaPliku.c_str());
			nasluch = !nasluch;
		}
		//pasek dolny
		string s = tresc_paska(); pasek->ustawString(s, "pasek_dolny");
		//PRZEKA� KLAWISZ DO W���CIWEGO EDYTORA
		AktywnyEdytor->klawisz_fizyczny(key, action);
		obraz();
		
	}
	void nasluch_plikow()//wywolywany tez w glownej petli
	{
		for (int i = 0; i < ile_edytorow; i++) { Edytory[i]->przeladuj_z_pliku(); }
		obraz();
	}
	void klawisz_logiczny(unsigned int in)
	{
		//printf("generator:log\n");
		AktywnyEdytor->klawisz_logiczny(in);
		//obraz();
	}
	void upuszczonoPlik(const char * nazwap)
	{
		printf("UPUSZCZONO_PLIK!\n%s\n", nazwap);
		string nz(nazwap);
		cout << nz;
		string  s = wczytajPlik(nazwap);
		AktywnyEdytor->ustawString(s, string(nazwap));
		obraz();
	}
	string  wczytajPlik(const char * nazwap)
	{
		/*ifstream plik; string wyjscie;
		plik.open(nazwap, ios::binary | ios::ate);
		auto dl = plik.tellg();
		cout << "\nplik o wielkosci" << dl << "\n";
		if (dl < 1)
		{
			wyjscie = string("Cos jest nie tak z plikiem") + string(nazwap) + "\nalbo wystapil inny blad";
		}
		else if (dl > 16 * 1024)
		{
			wyjscie = "Niestety jestem tylko mikrym czyms, co nieudolnie udaje edytor\nDlatego nie umiem przeczytac tak dlugiego pliku\nprzepraszam";
		}
		else { plik >> wyjscie; }
		cout << "@\n" << wyjscie << endl;
		/*/
		std::ifstream t(nazwap);
		std::stringstream buffer;
		auto dl = t.tellg();
		buffer << t.rdbuf();
		//cout << buffer.str();
		//cout << "EOF\n";
		return buffer.str();
	}

private:

};
