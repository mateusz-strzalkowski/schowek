#pragma once
//sic! tak to si� powinno po polsku nawywa�!
void parametry(const char *, unsigned int);
