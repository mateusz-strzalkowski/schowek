﻿//matematyka typu GLSL (wektory itd)
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include<misc/ttf.h>			//generacja metryk czcionek true type do póżniejszego użytku
#include <misc/shader_s.h>	//klasa obsługująca ładnie shadery
#include "turboVertexAttribPtr.h"

#define VBOSIZE 12888
#pragma once
using namespace glm;
class Pisacz3d
{
public:
	Shader * shader = nullptr;
	TTF * ttf = nullptr;
	vec3 poz, rown, prost;
	float skala = 0.0;
	vec3 textColor = vec3(1, 1, 1);

	int bufOffset = 0;

	mat4 * projection; mat4 * view; mat4 * model;

	unsigned int txtVAO, txtVBO;

	Pisacz3d(const char * vertexSh, const char* fragmentSh, const char * ttfPath, unsigned int rozdzielczosc)
	{
		//shader = new Shader(vertexSh, fragmentSh);
		ttf = new TTF("czcionki/arial.ttf", rozdzielczosc);
		shader = new Shader("cieniowacze/tekst3d.vert", "cieniowacze/tekst3d.frag");
		glGenVertexArrays(1, &txtVAO);
		glGenBuffers(1, &txtVBO);
		glBindVertexArray(txtVAO);
		glBindBuffer(GL_ARRAY_BUFFER, txtVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 6 * 5, NULL, GL_DYNAMIC_DRAW);
		glEnableVertexAttribArray(0);
		parametry("vec3, vec2", txtVAO);
		glBindVertexArray(0);
		//bufor dla zaznaczeń i kursora
		//ustawienia do rysowania czcionek
		//printf("tekst3d: glGetError() : %d\n", glGetError());
	}
	~Pisacz3d()
	{
		delete shader;
		delete ttf;
	}
	void zaczepienieZnakow3d( vec3 Poz, vec3 Rown, vec3 Prost, float Skala);
	void RysujZnak(unsigned char c);
	//void RysujBufor();
};