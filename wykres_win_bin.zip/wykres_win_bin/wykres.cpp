#define _CRT_SECURE_NO_WARNINGS
//Opengl
#include <glad/glad.h>
#include <GLFW/glfw3.h>

//matematyka typu GLSL (wektory itd)
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//czcionki
#include <ft2build.h>
#include FT_FREETYPE_H

//r�no�ci
#include <misc/stb_image.h>		//�adowanie obrazk�w
#include <misc/shader_s.h>	//klasa obs�uguj�ca �adnie shadery
#include <misc/shader_dyn.h>
#include <misc/camera.h>
#include <misc/kamera_3os.h>		//klasa kamery tr�jwymiarowej
#include <misc/render_text.h>	//proste wypisanie linii tekstu
#include<misc/ttf.h>			//generacja metryk czcionek true type do p�niejszego u�ytku
#include <iostream>
#include <conio.h>
#include <map>
#include <vector>
#include "generator.h"			//obiekt zarz�dzaj�cy edytorami, automatyczn� generacj� kodu �r�d�owego GLSL oraz jego kompilacj� i podmian� shadera na �ywca
#include "objRysowany.h"
#include "podzialka.h"
#include "flagi.h"
//#include "czarne.h"

//kolor promieniowania cia�a doskonale czarnego
extern "C" {
	// Get declaration for f(int i, char c, float x)
#include "czarne.h"
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow *window);
void character_callback(GLFWwindow* window, unsigned int codepoint);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void drop_callback(GLFWwindow* window, int count, const char** paths);

void uniformy_swietlne(DynamicShader *);//�eby main da�o si� czyta�

// ustawienia 900x600
unsigned int szer_okna = 1920;
unsigned int wys_okna = 1080;

// kamera
Camera kamera(glm::vec3(0.0f, 0.0f, 3.0f));
//Kamera3os kamera(glm::vec3(0.0f, 0.0f, 0.0f));
float lastX = szer_okna / 2.0f;
float lastY = wys_okna / 2.0f;
bool firstMouse = true;

//Kamera3os trzy(glm::vec3(0.0f, 0.0f, 0.0f));

// czas
float deltaT = 0.0f;
float ostKlatka = 0.0f;

//zdarzenia czasowe
float ost_nasluch_pliku = 0.0f;
float ost_klawisz_logiczny = 0.0f;

// lighting
glm::vec3 lightPos(0.8f, 1.0f, 2.0f);
glm::vec3 lightColor(1.0, 1.0, 1.0);
float temperatura = 5778;
float temp_docelowa = 5778;
int shiness = 2;

//edytor
Generator * generator = nullptr;

//#define LICZBA_WIERSZY 20
bool ruch_kamery = true;
//WYKRES
int rozdzielczosc_siatki_wykresu = 2700;
int n=rozdzielczosc_siatki_wykresu;
glm::vec3 przesuniecie_wykresu = glm::vec3(0, 0, 0);
float rozpietosc_wykresu = 1.0;
float czas_wykresu = 0.0;
float szybkosc_czasu_wykr = 1.0;
bool pauza = true;

static int stan_kursora = GLFW_CURSOR_DISABLED;

//czcionki 
TTF * czcionki;

int main()
{
	// glfw: inicjalizacja
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // uncomment this statement to fix compilation on OS X
#endif
	//halo();
	// glfw tworzenie okna
	// --------------------
	GLFWwindow* window = glfwCreateWindow(szer_okna, wys_okna, "LearnOpenGL", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	//callbacki
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);
	glfwSetCharCallback(window, character_callback);
	glfwSetKeyCallback(window, key_callback);
	glfwSetDropCallback(window, drop_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);

	//wylaczenie widodcznego kursora
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


	// glad: zaladuj wskazniki na funkcje OpenGl
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// konfiguracja globalnego stanu OpenGl
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	//skompiluj i zbuduj shadery
	// -------------------------
	//Shader ourShader("1.model_loading.vert", "1.model_loading.frag");


	// linie niewype�nione
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	PrepareforTextRendering("czcionki/arial.ttf", 48);
	czcionki = new TTF("czcionki/gtw.ttf", 48);


	//napis
	Napis zegarek(glm::vec2(-1.0, 0.9), czcionki);
	zegarek.liczba_linii = 26; string s = "NULL";
	zegarek.ustawString( s, "czas");
	zegarek.textColor = glm::vec3(0.1, 0.9, 0.4);

	Napis fpsy(glm::vec2(0.5, 0.9), czcionki);
	fpsy.liczba_linii = 26; string a = "NULL";
	fpsy.ustawString(a, "fps");
	fpsy.textColor = glm::vec3(0.2, 0.6, 0.6);

	Napis termometr(glm::vec2(0.7, 0.8), czcionki);
	termometr.liczba_linii = 28; string trm = "NULL";
	termometr.ustawString(trm, "tmp");
	termometr.textColor = glm::vec3(0.2, 0.3, 0.3);

	//Edytor edytorGlowny(glm::vec2(-1,0));
	//aktywnyEdytor = &edytorGlowny;
	// build and compile our shader program
	// ------------------------------------
	Shader interfejsuShader("cieniowacze/ramkobufor_plasko.vert", "cieniowacze/ramkobufor_plasko.frag");
	Shader s1("cieniowacze/1.vert", "cieniowacze/1.frag"); // you can name your shader files however you like
	//Shader textShader("cieniowacze/text.vert", "cieniowacze/text.frag");

// build and compile our shader zprogram
	// ------------------------------------
	Shader lightingShader("cieniowacze/1.colors.vert", "cieniowacze/1.colors.frag");
	Shader lampShader("cieniowacze/1.lamp.vert", "cieniowacze/1.lamp.frag");

	

	//WYKRES 3D- ustawienie obiekt�w OPENGL-a
	//Cieniowacz (Shader)
	DynamicShader wykresuShader("cieniowacze/wykres.vert", "cieniowacze/wykres.frag");
	// VAO i VBO (Vertex Array Object i Vertex Buffer Object - ten ostatni tutaj wyj�tkowo pusty)
	unsigned int wykrVBO, wykrVAO;
	glGenVertexArrays(1, &wykrVAO);
	glGenBuffers(1, &wykrVBO);

	glBindBuffer(GL_ARRAY_BUFFER, wykrVBO);
	glBufferData(GL_ARRAY_BUFFER, 0, NULL, GL_STATIC_DRAW);

	glBindVertexArray(wykrVAO);

	// atrubuty, kt�rych NIE MA!
	//glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	//glEnableVertexAttribArray(0);

	/////////////
	//GENERATOR//
	/////////////
	generator = new Generator(window, &wykresuShader);

	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------
	float vertices[] = {
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
		 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,

		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,

		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,
		-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
		-0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,

		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,

		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,
		 0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
		-0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,

		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f
	};
	// first, configure the cube's VAO (and VBO)
	unsigned int VBO, cubeVAO;
	glGenVertexArrays(1, &cubeVAO);
	glGenBuffers(1, &VBO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glBindVertexArray(cubeVAO);

	// position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// normal attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);


	// second, configure the light's VAO (VBO stays the same; the vertices are the same for the light object which is also a 3D cube)
	unsigned int lightVAO;
	glGenVertexArrays(1, &lightVAO);
	glBindVertexArray(lightVAO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	// note that we update the lamp's position attribute's stride to reflect the updated buffer data
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	/////////

	//ObjRysowany klocek(&lightingShader, NULL, 0, string("vec3, vec2"));

	/////////////////////////////////////////////////////////////////

		//kwadrat teksturowany buforem interfejsu
	float quadVertices[] = { // vertex attributes for a quad that fills the entire screen in Normalized Device Coordinates.
		// positions   // texCoords
		-1.0f,  1.0f,  0.0f, 1.0f,
		-1.0f, -1.0f,  0.0f, 0.0f,
		 1.0f, -1.0f,  1.0f, 0.0f,

		-1.0f,  1.0f,  0.0f, 1.0f,
		 1.0f, -1.0f,  1.0f, 0.0f,
		 1.0f,  1.0f,  1.0f, 1.0f
	};
	// screen quad VAO
	unsigned int quadVAO, quadVBO;
	glGenVertexArrays(1, &quadVAO);
	glGenBuffers(1, &quadVBO);
	glBindVertexArray(quadVAO);
	glBindBuffer(GL_ARRAY_BUFFER, quadVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(quadVertices), &quadVertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));

	//osie wykresu
	float wierzcholki_osi[] = {
		0, 0, 0.5,
		1,  0, 0.5,

		0.5, 0, 0,
		0.5, 0, 1,

		0.5, -0.5, 0.5,
		0.5, +0.5, 0.5
	};
	int nwierzch_osi = 6;
	Shader shaderOsi("cieniowacze/osie.vert", "cieniowacze/osie.frag");
	ObjRysowany osie( wierzcholki_osi, nwierzch_osi, "vec3", GL_LINES);

	Podzialka podzialka;

	//podzialk� trzeba przesun�� i pomniejszy�
	glm::mat4 scale = glm::mat4(1.0f);
	scale = glm::scale(scale, glm::vec3(0.5, 0.5, 0.5));
	glm::mat4 trans = glm::mat4(1.0f);
	trans = glm::translate(trans, glm::vec3(0.5f, 0.0f, +0.5f));

	glm::mat4 PrzesuniecieIPrzeskalowaniePodzialki = trans * scale;

	generator->obraz();//wygeneruj po raz pierwszy interfejs

	// GL�WNA P�TLA
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// logika poklatkowa
		// --------------------
		static float s= glfwGetTime();
		if (glfwGetTime() - s > 1.0) { s = glfwGetTime(); }
		float currentFrame = glfwGetTime();
		deltaT = currentFrame - ostKlatka;
		ostKlatka = currentFrame;
		if (!pauza) { czas_wykresu += deltaT * szybkosc_czasu_wykr; }
		if (dynamiczna_rozdzielczosc)
		{
			if (deltaT < ( 1.0 / 55.0) && deltaT > 0.008) { rozdzielczosc_siatki_wykresu += 10; /*printf("rzdz:%d\n", rozdzielczosc_siatki_wykresu);*/ }
			if (deltaT > (1.0 / 53.0) && rozdzielczosc_siatki_wykresu > 200) { rozdzielczosc_siatki_wykresu -= 10; /*printf("rzdz:%d\n", rozdzielczosc_siatki_wykresu);*/ }
		}
		if (deltaT > 1.0 / 10 && rozdzielczosc_siatki_wykresu > 64) { rozdzielczosc_siatki_wykresu /=2; printf("uwaga lagi %d\n", rozdzielczosc_siatki_wykresu); }
		if (czy_temperatura)
		{
			if (temperatura < temp_docelowa) { temperatura += 10; }
			if (temperatura > temp_docelowa) { temperatura -= 10; }
			float * k = czarne(temperatura);
			lightColor.r = k[0]; lightColor.g = k[1]; lightColor.b = k[2];
		}
		else { lightColor = vec3(1, 1, 1); }
		// zdarzenia po jakims czasie
		// --------------------
		if (currentFrame - ost_nasluch_pliku > 1.0)
		{
			ost_nasluch_pliku = currentFrame;
			if (nasluch) { generator->nasluch_plikow(); }
		}
		if (currentFrame - termin_modyfikacji > opoznienie_kompilacji && termin_modyfikacji != 0.0)
		{
			termin_modyfikacji = 0.0;//tzn zostala wykonana
			generator->kompiluj();
		}

		// wej�cie
		// -----
		processInput(window);

		glEnable(GL_DEPTH_TEST);
		/// rysowanie
		// ------
		glClearColor(0.1f, 0.1f, 0.1f, 0.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//////////////////////////////////////////////////////////////////////////
						// be sure to activate shader when setting uniforms/drawing objects
				
				lightingShader.use();
				lightingShader.setVec3("objectColor", 1.0f, 0.5f, 0.31f);
				lightingShader.setVec3("lightColor", lightColor);
				lightingShader.setVec3("lightPos", lightPos);
				lightingShader.setVec3("viewPos", kamera.Position);
				lightingShader.setInt("shiness", shiness);

				//material
				lightingShader.setVec3("material.ambient", 0.25f, 0.25f, 0.35f);
				lightingShader.setVec3("material.diffuse", 0.4f, 0.4f, 0.50f);
				lightingShader.setVec3("material.specular", 0.774597f, 0.774597f, 0.774597f);
				lightingShader.setFloat("material.shininess", 128 * 0.6f);

				//light
				lightingShader.setVec3("light.ambient", 0.2f, 0.2f, 0.2f);
				lightingShader.setVec3("light.diffuse", 1.0f, 1.0f, 1.0f); // darken the light a bit to fit the scene
				lightingShader.setVec3("light.specular", 1.0f, 1.0f, 1.0f);
				
		//

		// view/projection transformations
		glm::mat4 projection = glm::perspective(glm::radians(kamera.Zoom), (float)szer_okna / (float)wys_okna, 0.1f, 100.0f);
		glm::mat4 view = kamera.GetViewMatrix();
		lightingShader.setMat4("projection", projection);
		lightingShader.setMat4("view", view);

		// world transformation
		glm::mat4 model = glm::mat4(1.0f);
		lightingShader.setMat4("model", model);

		// render the cube
		glBindVertexArray(cubeVAO);
		//glDrawArrays(GL_TRIANGLES, 0, 36);


		// also draw the lamp object
		lampShader.use();
		lampShader.setMat4("projection", projection);
		lampShader.setMat4("view", view);
		model = glm::mat4(1.0f);
		model = glm::translate(model, lightPos);
		model = glm::scale(model, glm::vec3(0.2f)); // a smaller cube
		lampShader.setMat4("model", model);
		lampShader.setVec3("lightColor", lightColor);


		glBindVertexArray(lightVAO);
		glDrawArrays(GL_TRIANGLES, 0, 36);

		if (czy_podzialka)
		{
			shaderOsi.use();
			shaderOsi.setMat4("projection", projection);
			shaderOsi.setMat4("view", view);
			shaderOsi.setMat4("model", glm::mat4(1.0f));
			osie.rysuj();


			shaderOsi.setMat4("model", PrzesuniecieIPrzeskalowaniePodzialki);
			
			podzialka.pisacz3d->model = &PrzesuniecieIPrzeskalowaniePodzialki;
			podzialka.pisacz3d->projection = &projection;
			podzialka.pisacz3d->view = &view;
			podzialka.shader_osi = &shaderOsi;
			//podzialka.pisacz3d->macierze(projection, view, PrzesuniecieIPrzeskalowaniePodzialki);
			podzialka.rysuj(rozpietosc_wykresu, przesuniecie_wykresu);
		}

		//////////////////////////////////////////////////////////////////////////

		  ///////////////
		 // WYKRES 3D //
		///////////////
		{
			int s = rozdzielczosc_siatki_wykresu;
			wykresuShader.use();
			uniformy_swietlne(&wykresuShader);
			// view/projection transformations
			glm::mat4 projection = glm::perspective(glm::radians(kamera.Zoom), (float)szer_okna / (float)wys_okna, 0.1f, 100.0f);
			glm::mat4 view = kamera.GetViewMatrix();
			wykresuShader.setMat4("projection", projection);
			wykresuShader.setMat4("view", view);

			// world transformation
			glm::mat4 model = glm::mat4(1.0f);
			wykresuShader.setMat4("model", model);

			wykresuShader.setInt("szer", s);
			wykresuShader.setVec3("przesuniecie", przesuniecie_wykresu);
			wykresuShader.setFloat("rozpietosc", rozpietosc_wykresu);
			wykresuShader.setFloat("t", czas_wykresu);

			// renderowanie
			if (wireframe){glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); }

			glBindVertexArray(wykrVAO);
			//glDrawArrays(GL_TRIANGLE_STRIP, 0, (2*s+1)*(s-1));
			glDrawArrays(GL_TRIANGLE_STRIP, 0, 2 * (s + 1)*(s - 1));
			if (wireframe) { glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); }
		}


		//////////////////
	   //koniec wykresu//
	  //////////////////
		char czasbuf[32];
		sprintf(czasbuf, "t=%.3f", czas_wykresu);
		string cz(czasbuf);
		zegarek.ustawString(cz, "czas");
		zegarek.pisz();

		cz = to_string((int)(1.0 / deltaT)) + string("FPS @res") + to_string(rozdzielczosc_siatki_wykresu);
		fpsy.ustawString(cz, "fps");
		fpsy.pisz();

		if (czy_temperatura)
		{
			cz = to_string((int)(temperatura)) + "K";
			termometr.ustawString(cz, "termometr");
			termometr.pisz();
		}


			  ///na to ramkobufor interfejsu
			  //glBindFramebuffer(GL_FRAMEBUFFER, 0);
			  //glDisable(GL_DEPTH_TEST); // disable depth test so screen-space quad isn't discarded due to depth test.
			  // clear all relevant buffers

			  //glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		interfejsuShader.use();
		interfejsuShader.setInt("screenTexture", 0);
		glBindVertexArray(quadVAO);
		glBindTexture(GL_TEXTURE_2D, generator->textureColorbuffer);	// use the color attachment texture as the texture of the quad plane
		glDrawArrays(GL_TRIANGLES, 0, 6);

		glDisable(GL_BLEND);


		// glfw: zamie� bufory i pobierz zdarzenia we/wy
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// glfw: umrzyj
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

void uniformy_swietlne(DynamicShader * sh)
{
	sh->use();
	sh->setVec3("objectColor", 1.0f, 0.5f, 0.31f);
	sh->setVec3("lightColor", lightColor);
	sh->setVec3("lightPos", lightPos);
	sh->setVec3("viewPos", kamera.Position);
	sh->setInt("shiness", shiness);

	//material
	sh->setVec3("material.ambient", 0.20f, 0.65f, 0.35f);
	sh->setVec3("material.diffuse", 0.3f, 0.35f, 0.6f);
	sh->setVec3("material.specular", 0.974597f, 0.974597f, 0.974597f);
	sh->setFloat("material.shininess", 128 * 0.6f);

	//light
	float jasn = temperatura / 6000;
	sh->setVec3("light.ambient", jasn*0.2f*lightColor);
	sh->setVec3("light.diffuse", jasn*lightColor); // darken the light a bit to fit the scene
	sh->setVec3("light.specular", jasn*lightColor);
}
// przetwarzanie klawiszy fizycznych
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (ruch_kamery)
	{
		if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
			kamera.ProcessKeyboard(FORWARD, deltaT);
		if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
			kamera.ProcessKeyboard(BACKWARD, deltaT);
		if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
			kamera.ProcessKeyboard(LEFT, deltaT);
		if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
			kamera.ProcessKeyboard(RIGHT, deltaT);
	}
}

//klawisze fizyczne, ale generowane tylko na zdarzeniach, a nie na  �yczenie jak wy�ej
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_MENU && (action == GLFW_PRESS )) { ruch_kamery = (!ruch_kamery); cout << "ZABLOKOWANIE/ODBLOKOWANIE PORUSZANIA KAMER� NA BOKI/WPISYWANIA TEKSTU" << endl; }
	if (key == GLFW_KEY_KP_ADD && action != GLFW_RELEASE) { rozdzielczosc_siatki_wykresu*=1.1; printf("n:%d\n", rozdzielczosc_siatki_wykresu); }
	if (key == GLFW_KEY_KP_SUBTRACT && action != GLFW_RELEASE) { rozdzielczosc_siatki_wykresu*=0.9; printf("n:%d\n", rozdzielczosc_siatki_wykresu);}
	if (key == GLFW_KEY_KP_8 && action != GLFW_RELEASE) { przesuniecie_wykresu.z += 0.01*rozpietosc_wykresu; }
	if (key == GLFW_KEY_KP_2 && action != GLFW_RELEASE) { przesuniecie_wykresu.z -= 0.01*rozpietosc_wykresu; }
	if (key == GLFW_KEY_KP_4 && action != GLFW_RELEASE) { przesuniecie_wykresu.x += 0.01*rozpietosc_wykresu; }
	if (key == GLFW_KEY_KP_6 && action != GLFW_RELEASE) { przesuniecie_wykresu.x -= 0.01*rozpietosc_wykresu; }
	if (key == GLFW_KEY_KP_5 && action != GLFW_RELEASE) { przesuniecie_wykresu.y += 0.01*rozpietosc_wykresu; }
	if (key == GLFW_KEY_KP_0 && action != GLFW_RELEASE) { przesuniecie_wykresu.y -= 0.01*rozpietosc_wykresu; }
	if (key == GLFW_KEY_F11 && action == GLFW_PRESS) { dynamiczna_rozdzielczosc = !dynamiczna_rozdzielczosc; }

	//czas wykresu
	if (key == GLFW_KEY_PAUSE && action == GLFW_PRESS) { pauza = !pauza; printf("t:%f @%f\n", czas_wykresu, szybkosc_czasu_wykr); }
	if (glfwGetKey(window, GLFW_KEY_HOME) && glfwGetKey(window, GLFW_KEY_PAUSE)) { czas_wykresu = 0.0; }
	
	if (ruch_kamery)//klawisze kt�re robi� co� gdy pisanie jest wy��czone
	{
		if (key == GLFW_KEY_P && action == GLFW_PRESS) { czy_podzialka = !czy_podzialka; }
		if (key == GLFW_KEY_T && action == GLFW_PRESS) { czy_temperatura = !czy_temperatura; }
		if (key == GLFW_KEY_F && action == GLFW_PRESS) { wireframe = !wireframe; }
		if (key == GLFW_KEY_K && action == GLFW_PRESS) 
		{
			if (stan_kursora == GLFW_CURSOR_DISABLED)
			{
				glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
				stan_kursora = GLFW_CURSOR_NORMAL;
			}
			else {
				glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
				stan_kursora = GLFW_CURSOR_DISABLED;
			}
		}
	}

	generator->klawisz_fizyczny(key, action);
}


// przetwarzanie tekstu z klawiatury
// ---------------------------------------------------------------------------------------------
void character_callback(GLFWwindow* window, unsigned int codepoint)
{
	//printf("%c\t%d\n", codepoint, codepoint);
	if (!ruch_kamery) { generator->klawisz_logiczny(codepoint); }
}

// glfw: zmiana rozmiaru okna prez u�ytkownika albo przezsystem
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	if ( !(width == 0 && height == 0)) //tzn. ignoruje minimalizacj�, udaj�c, �e si� nic nie sta�o
	{
		glViewport(0, 0, width, height);
		wys_okna = height; szer_okna = width;
		generator->obraz();
	}
}

// glfw: poruszenie myszk�
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}
	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;
	if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) )
	{
		if(glfwGetKey(window, GLFW_KEY_LEFT_CONTROL))
		{
			przesuniecie_wykresu.y -= yoffset * rozpietosc_wykresu*0.008;
		}
		else {
			vec3 pt = glm::normalize(vec3(kamera.Front.x,0 ,kamera.Front.z)) * -yoffset * rozpietosc_wykresu * 0.008f;//prz�d - ty�
			vec3 lp = glm::normalize(vec3(kamera.Right.x,0,  kamera.Right.z)) * -xoffset * rozpietosc_wykresu * 0.008f;//lewo - prawo
			przesuniecie_wykresu += (pt + lp);
		}
	}

	else if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT))
	{
		if (glfwGetKey(window, GLFW_KEY_LEFT_CONTROL))
		{
			lightPos.y -= yoffset * rozpietosc_wykresu*0.008;
		}
		else {
			vec3 pt = glm::normalize(vec3(kamera.Front.x, 0, kamera.Front.z)) * -yoffset * rozpietosc_wykresu * 0.008f;//prz�d - ty�
			vec3 lp = glm::normalize(vec3(kamera.Right.x, 0, kamera.Right.z)) * -xoffset * rozpietosc_wykresu * 0.008f;//lewo - prawo
			lightPos += (pt + lp)*-0.1f;
		}
	}
	else if (stan_kursora == GLFW_CURSOR_DISABLED)
	{

		kamera.ProcessMouseMovement(xoffset, yoffset);
	}

}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) && glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT))
	{
		if (stan_kursora == GLFW_CURSOR_DISABLED)
		{
			glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
			stan_kursora = GLFW_CURSOR_NORMAL;
		}
		else {
			glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); 
			stan_kursora = GLFW_CURSOR_DISABLED;
		}
	}
}


// glfw: kr�cenie k�lkiem myszy
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	//kamera.ProcessMouseScroll(yoffset);
	if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT))
	{
		temp_docelowa += 100 * (yoffset / abs(yoffset));
	}
	else { rozpietosc_wykresu *= (1 + 0.1*(yoffset / abs(yoffset))); }
}
//upuszczenie pliku na okienko
void drop_callback(GLFWwindow* window, int count, const char** paths)
{
	//int i;
	//for (i = 0; i < count; i++)
	//	handle_dropped_file(paths[i]);
	generator->upuszczonoPlik(paths[0]);
}
